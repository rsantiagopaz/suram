<?php

 phpinfo();
?> 