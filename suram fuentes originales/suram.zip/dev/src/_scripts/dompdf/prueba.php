<html>
<head>
<title>Solicitud</title>
</head>
<body>
<table width="3" height="2" border="1" align="center" cellpadding="0" cellspacing="0">
  <tr>
    <td><h1>$O$ CASH </h1></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>APELLIDO:</td>
    <td>$apllido</td>
  </tr>
  <tr>
    <td>NOMBRE:</td>
    <td>$nombre</td>
  </tr>
</table>
</body>
</html>