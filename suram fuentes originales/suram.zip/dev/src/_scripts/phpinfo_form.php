<html>
<body>
<form id="form1" name="form1" method="get" action="phpinfo.php">
  <p>PASO PARAMENTROS A PHPINFO </p>
  <p>Apellido: 
    <input name="apellido" type="text" id="apellido" />
  </p>
  <p>Nombre:
    <input name="nombre" type="text" id="nombre" />
  </p>
  <p>
    <input type="submit" name="Submit" value="Enviar" />
  </p>
  <p>&nbsp;  </p>
</form>


</body>
</html>