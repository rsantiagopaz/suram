<p><font color="#FF0000" size="3" face="Arial, Helvetica, sans-serif">En estos momentos estamos realizando 
  tareas de mantenimiento del sistema.</font></p>
<p><font color="#FF0000" size="3" face="Arial, Helvetica, sans-serif">Por favor, intente nuevamente m&aacute;s 
  tarde.</font></p>
<p><font color="#FF0000" size="3" face="Arial, Helvetica, sans-serif">Gracias.</font></p>
<p><font color="#FF0000" size="3" face="Arial, Helvetica, sans-serif">Administraci&oacute;n y Soporte T&eacute;cnico<br>
  www.sde.gov.ar</font></p>
