<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

if (!isset($filtro_pacientes))
	$filtro_pacientes = '';
if (!isset($fecha_desde))
	$fecha_desde = '';
if (!isset($fecha_hasta))
	$fecha_hasta = '';

switch ($_REQUEST['rutina'])
{
	case 'lista_pacientes': {				
		$xml=new SimpleXMLElement('<rows/>');
		$sql="SELECT DISTINCT DATE_FORMAT(i.fecha_consulta_ingreso,'%d/%m/%Y') 'fecha_consulta_ingreso', ";
		$sql.="p.persona_nombre 'apeynom', ";
		$sql.="CASE p.persona_tipodoc WHEN 'D' THEN 'DNI' WHEN 'C' THEN 'LC' WHEN 'E' THEN 'LE' WHEN 'F' THEN 'CI' END as 'tipo_doc', ";
		$sql.="p.persona_dni 'nrodoc', IF (id_tipo_egreso IS NULL,'abierto','cerrado') 'estado', i.id_ingreso ";
		$sql.="FROM salud1._personas p, suram.ingresos i ";
		$sql.="WHERE i.organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."' ";
		$sql.="AND i.id_persona=p.persona_id ";
		$sql.="AND i.id_nivel='2' ";
		$sql.="AND REPLACE(p.persona_nombre,',','') LIKE REPLACE('%$filtro_pacientes%',',','') ";
		$sql.="AND i.id_ingreso=";
		$sql.="(SELECT MAX(id_ingreso) FROM suram.ingresos WHERE suram.ingresos.id_persona = p.persona_id) ";
		if ($fecha_desde == "" && $fecha_hasta=="")
			$sql.="ORDER BY i.fecha_consulta_ingreso DESC LIMIT 100";
		else {
			if ($fecha_desde != "")
				$sql.="AND fecha_consulta_ingreso >= '".YYYYDM($fecha_desde)."' ";
			if ($fecha_hasta != "")
				$sql.="AND fecha_consulta_ingreso <= '".YYYYDM($fecha_hasta)."' ";
			$sql.="ORDER BY i.fecha_consulta_ingreso DESC";
		}					
		toXML($xml, $sql, "pacientes");		
		header('Content-Type: text/xml');
		echo $xml->asXML();
			
		break;
	}
}
?>