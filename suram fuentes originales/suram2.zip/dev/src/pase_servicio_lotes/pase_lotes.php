<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case 'traer_combos': {
		$xml=new SimpleXMLElement('<rows/>');
		$id_area = $_SESSION['usuario_organismo_area_id'];

		$sql="SELECT id_organismo_area_servicio 'id_area_servicio', id_servicio, denominacion ";
		$sql.="FROM $salud._organismos_areas_servicios oas ";
		$sql.="INNER JOIN $salud._servicios USING(id_servicio) ";
		$sql.="WHERE oas.id_organismo_area='$id_area' ";
		$sql.="ORDER BY denominacion";		
		toXML($xml, $sql, "servicio");				
		
		$sql="SELECT persona_nombre, _personal.id_personal ";		
        $sql.="FROM _personal ";
        $sql.="INNER JOIN _organismos_areas_servicios ON _personal.id_areas_servicios = _organismos_areas_servicios.id_organismo_area_servicio AND ";
        $sql.="_organismos_areas_servicios.id_organismo_area_servicio IN ";
        $sql.="(";
            $sql.="SELECT id_organismo_area_servicio ";
            $sql.="FROM _organismos_areas_servicios ";
        	$sql.="WHERE id_organismo_area = '".$_SESSION['usuario_organismo_area_id']."' ";
        $sql.=") ";
        $sql.="INNER JOIN _organismos_areas ON _organismos_areas_servicios.id_organismo_area = _organismos_areas.organismo_area_id ";
        $sql.="INNER JOIN _servicios ON _organismos_areas_servicios.id_servicio = _servicios.id_servicio ";
        $sql.="INNER JOIN 024_profesiones ON _personal.id_profesion = 024_profesiones.id_profesion AND 024_profesiones.id_profesion IN ('1') ";        
        $sql.="INNER JOIN _personas ON _personal.dni = _personas.persona_dni ";
        $sql.="INNER JOIN _usuarios ON _personas.persona_id = _usuarios.id_persona ";
        $sql.="INNER JOIN oas_usuarios ON _personal.id_areas_servicios = oas_usuarios.id_organismo_area_servicio ";
        $sql.="AND _usuarios.SYSusuario = oas_usuarios.SYSusuario ";
        $sql.="ORDER BY persona_nombre ";                     
		toXML($xml, $sql, "medico");
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
	case "guardar":{
		$error = "";
		$fecha_pase = YYYYDM($fecha_pase);		
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT id_ingreso, IF (id_tipo_egreso IS NULL,'abierto','cerrado') 'estado', id_area_servicio_ingreso, ";
		$sql.="DATE_FORMAT(fecha_movimiento_ingreso,'%Y-%m-%d') 'fecha_movimiento_ingreso' ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="JOIN ingresos USING(id_ingreso) ";
		$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$id_ingreso = $row['id_ingreso'];
		$estado = $row['estado'];
		$id_servicio_desde = $row['id_area_servicio_ingreso'];			
		$fecha_ingreso_uno = new DateTime($row['fecha_movimiento_ingreso']);
		$fecha_ingreso_dos = new DateTime($fecha_pase);
		
		if ($fecha_ingreso_uno > $fecha_ingreso_dos) {
			$error .= "La fecha de pase al nuevo servicio debe ser mayor o igual a la fecha de ingreso al servicio anterior\n";
		}
		
		if ($id_servicio_desde == $id_servicio) {
			$error .= "El servicio de origen y el de destino deben ser distintos\n";
		}
		
		if ($error == "") {
			if ($estado == "cerrado") {
				$sql="UPDATE ingresos ";
				$sql.="SET id_tipo_egreso=NULL, ";
				$sql.="id_establecimiento_hacia=NULL ";
				$sql.="WHERE id_ingreso='$id_ingreso' ";
				$result = mysql_query($sql);
				
				$sql="UPDATE ingresos_movimientos ";
				$sql.="SET fecha_movimiento_egreso=NULL, ";
				$sql.="id_area_servicio_egreso=NULL, ";
				$sql.="id_recursos_humanos_egreso=NULL, ";
				$sql.="observaciones='' ";
				$sql.="WHERE id_ingreso_movimiento=(SELECT MAX(id_ingreso_movimiento) WHERE id_ingreso='$id_ingreso') ";
				$result = mysql_query($sql);			
			}
							
			$sql="UPDATE ingresos_movimientos ";
			$sql.="SET fecha_movimiento_egreso='$fecha_pase', ";
			$sql.="id_area_servicio_egreso='$id_servicio', ";
			$sql.="id_recursos_humanos_egreso='$id_medico', ";
			$sql.="observaciones='$observaciones' ";
			$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
			toXML($xml, $sql, "pase");
			
			$sql="INSERT INTO ingresos_movimientos ";
			$sql.="SET id_ingreso = '$id_ingreso', ";
			//$sql.="fecha_movimiento_ingreso = NOW(), ";
			$sql.="fecha_movimiento_ingreso = '$fecha_pase', ";
			$sql.="circunstancia_ingreso='P', ";
			$sql.="id_area_servicio_ingreso='$id_servicio'";		
			toXML($xml, $sql, "pase");
			$id_ingreso_movimiento_nuevo = mysql_insert_id();
			
			$sql="INSERT INTO items_diagnosticos ";
			$sql.="(SELECT '', $id_ingreso_movimiento_nuevo, id_diagnostico, tipo_diagnostico ";
			$sql.="FROM items_diagnosticos ";
			$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento')";
			toXML($xml, $sql, "pase");
					
			header('Content-Type: text/xml');
			echo $xml->asXML();	
		} else {
			$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
			$xml .= "<xml>";
			$xml .= "<error>$error</error>";			
			$xml.= "</xml>";
			header('Content-Type: text/xml');
			print $xml;
		}
		break;
	}
}
?>