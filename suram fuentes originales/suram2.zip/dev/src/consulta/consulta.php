<?php
include("../control_acceso_flex.php");
include("../rutinas.php");
include("../modelos/persona.php");

switch ($_REQUEST['rutina'])
{
	case 'traer_datos': {
		$xml=new SimpleXMLElement('<rows/>');
		$persona = new persona();
		
		$sql="SELECT * ";
		$sql.="FROM especialidades ";
		$sql.="ORDER BY especialidad";
		toXML($xml, $sql, "especialidad");

		$sql="SELECT * ";
		$sql.="FROM tipos_ingresos ";		
		toXML($xml, $sql, "tipoingreso");
		
		$sql="SELECT * ";
		$sql.="FROM traumatismo_lugar ";
		$sql.="ORDER BY descripcion";
		toXML($xml, $sql, "traumatismo_lugar");
		
		$sql="SELECT * ";
		$sql.="FROM traumatismo_producido_por ";
		$sql.="ORDER BY descripcion";
		toXML($xml, $sql, "traumatismo_producido");
		
		$sql="SELECT p.id_prescripcion, CONCAT(monodroga, ' ',presentacion, ' ',concentracion) 'descrip', ";
		$sql.="v.id_vademecum, p.posologia, v.monodroga, v.concentracion, v.presentacion, DATE_FORMAT(fecha_prescripcion,'%d/%m/%Y') 'fecha_prescripcion' ";
		$sql.="FROM ingresos_movimientos im ";
		$sql.="INNER JOIN prescripciones p USING(id_ingreso_movimiento) ";
		$sql.="INNER JOIN vademecum v USING(id_vademecum) ";		
		$sql.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$sql.="ORDER BY fecha_prescripcion";	
		toXML($xml, $sql, "prescripcion");
		
		$sql="SELECT id.id_item_diagnostico, id.id_ingreso_movimiento, id.id_diagnostico, CONCAT(cie10.cod_4,' - ',cie10.descripcion4) 'coddescrip', cie10.descripcion4 'descripcion', tipo_diagnostico,  cie10.cod_4 'codigo' ";
		$sql.="FROM ingresos_movimientos im ";
		$sql.="INNER JOIN items_diagnosticos id USING(id_ingreso_movimiento) ";
		$sql.="INNER JOIN cie10 USING(id_diagnostico) ";		
		$sql.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$sql.="ORDER BY cie10.descripcion4";	
		toXML($xml, $sql, "diagnostico");
		
		$sql="SELECT ib.id_ingreso_bebe, ib.id_ingreso, ib.peso, ";
		$sql.="ib.condicion_alnacer, IF(ib.condicion_alnacer='V','Nacido Vivo','Defuncion Fetal') 'condicion_alnacer_text', ";
		$sql.="ib.terminacion, IF(ib.terminacion='V','Vaginal','Cesárea') 'terminacion_text', ";
		$sql.="ib.sexo,(CASE WHEN sexo='M' THEN 'MASCULINO' WHEN sexo='F' THEN 'FEMENINO' WHEN sexo='I' THEN 'INDEFINIDO' END) 'sexo_text' ";
		$sql.="FROM ingresos_movimientos im ";
		$sql.="INNER JOIN ingresos i USING(id_ingreso) ";
		$sql.="INNER JOIN ingresos_bebes ib USING(id_ingreso) ";		
		$sql.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$sql.="ORDER BY peso";	
		toXML($xml, $sql, "nacimiento");
		
		$sql="SELECT IF (i.embarazo_fechaterminacion IS NULL,'00/00/0000',DATE_FORMAT(i.embarazo_fechaterminacion,'%d/%m/%Y')) 'embarazo_fechaterminacion', ";
		$sql.="IF (i.embarazo_edad_gestacional IS NULL,'0',i.embarazo_edad_gestacional) 'embarazo_edad_gestacional', i.embarazo_paridad, ";
		$sql.="embarazo_tipo_parto, IF(embarazo_tipo_parto='S','Simple','Multiple') 'embarazo_tipo_parto_text', ";
		$sql.="i.traum_comoseprodujo, i.id_traum_lugar, i.id_traum_producido, ";
		$sql.="tp.descripcion 'tp_desc', tl.descripcion 'tl_desc', ";
		$sql.="i.embarazada , i.traumatismo, im.observaciones ";
		$sql.="FROM ingresos_movimientos im ";
		$sql.="INNER JOIN ingresos i USING(id_ingreso) ";
		$sql.="LEFT JOIN traumatismo_lugar tl USING(id_traum_lugar) ";
		$sql.="LEFT JOIN traumatismo_producido_por tp ON tp.id_trau_producido=i.id_traum_producido ";
		$sql.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		toXML($xml, $sql, "datosinternacion");
		
		$sql="SELECT s.id_solicitudes, np.procedimiento 'descripcion', s.estado, s.resultados, id_practica, id_ingreso_movimiento_solicitud, DATE_FORMAT(fecha_solicitud,'%d/%m/%Y') as 'fecha_solicitud'  ";
		$sql.="FROM solicitudes s ";
		$sql.="INNER JOIN nomenclador_practicas np USING(id_practica) ";
		$sql.="INNER JOIN  ingresos_movimientos im ON  s.id_ingreso_movimiento_solicitud = im.id_ingreso_movimiento ";
		$sql.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$sql.="ORDER BY fecha_solicitud";
		toXML($xml, $sql, "practica");
				
		$sql= "SELECT id_dosis, CONCAT(nombre,' - dosis ',denominacion) as nombre, enfermedades ";		
		$sql.= "FROM $salud.027_vacunas JOIN $salud.027_dosis USING(id_vacuna) ";		
		$sql.= "ORDER BY nombre";
		toXML($xml, $sql, "vacunas");
				
		$query = "SELECT id_persona FROM ingresos INNER JOIN ingresos_movimientos im USING(id_ingreso) ";
		$query.="WHERE im.id_ingreso_movimiento='$id_ingreso_movimiento' ";
		$result = mysql_query($query);
		
		if ($row = mysql_fetch_array($result)){						
			$id_persona = $row['id_persona'];

			$respuesta = $persona->buscar($id_persona);
			toXMLResult($xml, $respuesta['error'], $respuesta['resultado'], "paciente");						
			
			$sql="SELECT f.id_financiador, f.nombre, f.codigo_anssal, tf.descripcion ";
			$sql.="FROM $salud._personas p, ";		
			$sql.="$suram.padrones pa, ";
			$sql.="$suram.financiadores f, ";
			$sql.="$suram.tipos_financiadores tf ";
			$sql.="WHERE p.persona_id='$id_persona' ";
			$sql.="AND tf.id_tipo_financiador=f.id_tipo_financiador ";
			$sql.="AND f.id_financiador=pa.id_financiador ";
			//$sql.="AND (p.persona_dni=pa.nrodoc AND p.persona_tipodoc=pa.tipo_doc) ";
			$sql.="AND p.persona_dni=pa.nrodoc ";
			$sql.="ORDER BY nombre";
			toXML($xml, $sql, "cobertura");	
			
			$sql="SELECT 'V' as 'estado', id_vacunacion, id_dosis, CONCAT(nombre,' - dosis ',denominacion) as nombre, enfermedades, ";
			$sql.=" DATE_FORMAT(id_fecha,'%d/%m/%Y') 'fecha' ";
			$sql.="FROM $salud.027_vacunaciones ";
			$sql.="JOIN $salud.027_dosis USING(id_dosis) ";
			$sql.="JOIN $salud.027_vacunas USING(id_vacuna) ";
			$sql.="WHERE id_persona='$id_persona' ";
			$sql.="ORDER BY fecha";
			toXML($xml, $sql, "vacunaciones");						
			
			$sql="SELECT 'V' as 'estado', a.id_antec_persona, descripcion, id_antecedente, antecedente, observaciones, persona_nombre as medico, ";			
			$sql.="CASE accion WHEN 'A' THEN 'Agregó' WHEN 'B' THEN 'Quitó' WHEN 'M' THEN 'Modificó' END as 'accion', ";
			$sql.=" DATE_FORMAT(fecha,'%d/%m/%Y') 'fecha' ";
			$sql.="FROM $salud.027_antecedentes_personas a ";
			$sql.="JOIN $salud.027_antecedentes USING(id_antecedente) ";
			$sql.="JOIN $salud.027_tipo_antec USING(id_tipo_antec) ";
			$sql.="JOIN $salud._usuarios u ON a.usuario = u.SYSusuario ";
			$sql.="JOIN $salud._personas p ON u.id_persona = p.persona_id ";
			$sql.="WHERE a.id_persona='$id_persona' ";
			$sql.="ORDER BY fecha";
			toXML($xml, $sql, "antecedente");
			
		}		
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
}
?>