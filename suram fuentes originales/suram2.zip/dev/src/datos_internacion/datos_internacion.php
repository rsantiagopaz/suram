<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case "guardar":{
		$xml=new SimpleXMLElement('<rows/>');
		
		$_REQUEST["datos"] = str_replace('\"','"',$_REQUEST["datos"]);
		$xmlDatos = loadXML($_REQUEST["datos"]);	
		
		$_REQUEST["diagnosticos"] = str_replace('\"','"',$_REQUEST["diagnosticos"]);
		$xmlDiagnosticos = loadXML($_REQUEST["diagnosticos"]);
		
		$_REQUEST["nacimiento"] = str_replace('\"','"',$_REQUEST["nacimiento"]);
		$xmlNacimiento = loadXML($_REQUEST["nacimiento"]);
		
		$sql="SELECT id_ingreso ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso_movimiento='".$xmlDatos["id_ingreso_movimiento"]."' ";
		$row = mysql_query($sql);
		$rs = mysql_fetch_array($row);
		$id_ingreso = $rs['id_ingreso'];
		
		
		$sql="DELETE FROM items_diagnosticos ";
		$sql.="WHERE id_ingreso_movimiento='".$xmlDatos["id_ingreso_movimiento"]."'";
		toXML($xml, $sql, "del");
		
		$sql="DELETE FROM ingresos_bebes ";
		$sql.="WHERE id_ingreso='$id_ingreso'";
		toXML($xml, $sql, "del");
		
		$sql="UPDATE ingresos ";
		$sql.="SET id_traum_producido='".$xmlDatos["id_traum_producido"]."', ";
		$sql.="traumatismo='".$xmlDatos["traumatismo"]."', ";
		$sql.="embarazada='".$xmlDatos["embarazada"]."', ";
		$sql.="id_traum_lugar='".$xmlDatos["id_traum_lugar"]."', ";
		$sql.="traum_comoseprodujo='".$xmlDatos["traum_comoseprodujo"]."', ";
		$sql.="embarazo_fechaterminacion='".YYYYDM($xmlDatos["embarazo_fechaterminacion"])."', ";
		$sql.="embarazo_edad_gestacional='".$xmlDatos["embarazo_edad_gestacional"]."', ";
		$sql.="embarazo_tipo_parto='".$xmlDatos["embarazo_tipo_parto"]."', ";
		$sql.="embarazo_paridad='".$xmlDatos["embarazo_paridad"]."' ";
		$sql.="WHERE id_ingreso='$id_ingreso'";
		toXML($xml, $sql, "ingreso");
		

		foreach ($xmlDiagnosticos->diagnostico as $diagnostico) {
    		$sql=" INSERT INTO items_diagnosticos SET ";
    		$sql.="id_diagnostico='".$diagnostico["id_diagnostico"]."', ";
    		$sql.="tipo_diagnostico='".$diagnostico["tipo_diagnostico"]."', ";
    		$sql.="id_ingreso_movimiento='".$xmlDatos["id_ingreso_movimiento"]."' ";
    		toXML($xml, $sql, "diagnosticos");
		}

		$i=1;		
		foreach ($xmlNacimiento->nacimiento as $nac) {
    		$sql=" INSERT INTO ingresos_bebes SET ";
    		$sql.="peso='".$nac["peso"]."', ";
    		$sql.="condicion_alnacer='".$nac["condicion_alnacer"]."', ";
    		$sql.="terminacion='".$nac["terminacion"]."', ";
    		$sql.="sexo='".$nac["sexo"]."', ";
    		$sql.="dni='".$xmlDatos["id_ingreso_movimiento"]."0".$i."', ";
    		$sql.="id_ingreso='$id_ingreso' ";
    		$i++;
    		toXML($xml, $sql, "nacimientos");
    		//dar de alta en _personas
    		
    		//crear el ingreso
    		
    		//crear el ingreso_movimiento
    		
		}
				
		header('Content-Type: text/xml');
		echo $xml->asXML();
		
		break;
	}
}
?>