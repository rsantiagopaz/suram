<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case "traer_diagnosticos":{
		$xml=new SimpleXMLElement('<rows/>');
		$sql= "SELECT id_diagnostico, descripcion4 'descripcion' ";
		$sql.= "FROM cie10 ";
		$sql.= "WHERE descripcion4 LIKE '%$descripcion%' ";
		$sql.= "ORDER BY descripcion ";
		
		$SELECT = mysql_query($sql);
		toXML($xml, $sql, "diagnostico");
		header('Content-Type: text/xml');
		echo $xml->asXML();

		break;
	}
}
?>