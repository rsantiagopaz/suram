<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case "traer_diagnosticos":{
		$xml=new SimpleXMLElement('<rows/>');
		$sql= "SELECT id_diagnostico, CONCAT(cod_4,' - ',descripcion4) 'coddescrip', cod_4 'codigo', descripcion4 'descripcion' ";
		$sql.= "FROM cie10 ";
		$sql.= "WHERE CONCAT(cod_4,' - ',descripcion4) LIKE '%$descripcion%' ";
		$sql.= "ORDER BY descripcion ";
		
		$SELECT = mysql_query($sql);
		toXML($xml, $sql, "diagnostico");
		header('Content-Type: text/xml');
		echo $xml->asXML();

		break;
	}
	case "traer_diagnostico":{
		$xml=new SimpleXMLElement('<rows/>');
		$sql= "SELECT id_diagnostico, CONCAT(cod_4,' - ',descripcion4) 'coddescrip', cod_4 'codigo', descripcion4 'descripcion' ";
		$sql.= "FROM cie10 ";
		$sql.= "WHERE cod_4='$codigo' ";
		
		$SELECT = mysql_query($sql);
		toXML($xml, $sql, "diagnostico");
		header('Content-Type: text/xml');
		echo $xml->asXML();

		break;
	}
}
?>