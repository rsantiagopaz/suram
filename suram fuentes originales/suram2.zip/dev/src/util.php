<?php
function genero_xml_ok_errores($_ok,$_errores,$otroNodoXml)
{	
	$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
	$xml.= "<xml>";
	if(!empty($_ok)) {
		$xml.=  "<ok>$_ok</ok>";
	}
	if(!empty($_errores)) { 
		$xml.=  "<error>$_errores</error>";
	}	
	$xml.=$otroNodoXml;	
	$xml.= "</xml>";
	header('Content-Type: text/xml');
	print $xml;
}

function transformarFecha($fecha)
{
    $fecha_vector     = explode('/',$fecha);
    // Cambia del formato dd/mm/aaaa al formato aaaa-mm-dd
    $fecha_convertida = $fecha_vector[2].'-'.$fecha_vector[1].'-'.$fecha_vector[0];
    // chequea que la fecha sea válida:
    // Veo si el año es mayor q 3000
    if ($fecha_vector[2]>3000 or $fecha_vector[2]<1900) {
		return '';
	} else {   
		if ( (!empty($fecha_vector[1]) and !empty($fecha_vector[0]) and !empty($fecha_vector[2]) ) and
	        (checkdate($fecha_vector[1],$fecha_vector[0],$fecha_vector[2])) ) {
		    return $fecha_convertida;
		} else {
		    return '';
		} 
	}	  
}
?>
