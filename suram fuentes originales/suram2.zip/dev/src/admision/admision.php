<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

function genero_xml_ok_errores($_ok,$_errores,$otroNodoXml)
{	
	$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
	$xml.= "<xml>";
	if(!empty($_ok)) {
		$xml.=  "<ok>$_ok</ok>";
	}
	if(!empty($_errores)) { 
		$xml.=  "<error>$_errores</error>";
	}	
	$xml.=$otroNodoXml;	
	$xml.= "</xml>";
	header('Content-Type: text/xml');
	print $xml;
}

function transformarFecha($fecha)
{
    $fecha_vector     = explode('/',$fecha);
    // Cambia del formato dd/mm/aaaa al formato aaaa-mm-dd
    $fecha_convertida = $fecha_vector[2].'-'.$fecha_vector[1].'-'.$fecha_vector[0];
    // chequea que la fecha sea válida:
    // Veo si el año es mayor q 3000
    if ($fecha_vector[2]>3000 or $fecha_vector[2]<1900) {
		return '';
	} else {   
		if ( (!empty($fecha_vector[1]) and !empty($fecha_vector[0]) and !empty($fecha_vector[2]) ) and
	        (checkdate($fecha_vector[1],$fecha_vector[0],$fecha_vector[2])) ) {
		    return $fecha_convertida;
		} else {
		    return '';
		} 
	}	  
}

switch ($_REQUEST['rutina'])
{
	case 'lista_financiadores': {
		$xml=new SimpleXMLElement('<rows/>');
		
		$query = "SELECT id_persona FROM $suram.ingresos WHERE id_ingreso = '$id_ingreso'";
		
		$result = mysql_query($query);
		
		/*if ($row = mysql_fetch_array($result)){						
			$id_persona = $row['id_persona'];
			
			$sql="SELECT id_financiador, nombre, codigo_anssal, descripcion ";
			$sql.="FROM personas p ";		
			$sql.="JOIN padrones USING(id_persona) ";
			$sql.="JOIN financiadores USING(id_financiador) ";
			$sql.="JOIN tipos_financiadores USING(id_tipo_financiador) ";
			$sql.="WHERE p.id_persona='$id_persona' ";
			$sql.="ORDER BY nombre";
		}*/
		if ($nro_doc){
		$sql="SELECT id_financiador, nombre, codigo_anssal, descripcion ";
			$sql.="FROM $suram.padrones ";			
			$sql.="JOIN $suram.financiadores USING(id_financiador) ";
			$sql.="JOIN $suram.tipos_financiadores USING(id_tipo_financiador) ";
			$sql.="WHERE nrodoc='$nro_doc' ";
			$sql.="ORDER BY nombre";
		
		toXML($xml, $sql, "cobertura");
		}
		header('Content-Type: text/xml');
		echo $xml->asXML();
	
		break;
	}
	case 'datos_paciente': {
		
		$xml=new SimpleXMLElement('<rows/>');
		
		$query = "SELECT id_persona FROM $suram.ingresos WHERE id_ingreso = '$id_ingreso'";
		
		$result = mysql_query($query);
		
		if ($row = mysql_fetch_array($result)){						
			$id_persona = $row['id_persona'];
			
			$sql="SELECT persona_id 'id_persona',persona_nombre 'apeynom', persona_tipodoc 'tipo_doc', persona_dni 'nrodoc', IF( persona_sexo = 'M', 'MASCULINO', 'FEMENINO' ) as 'sexo', ";
			$sql.="DATE_FORMAT(persona_fecha_nacimiento,'%d/%m/%Y') as 'fechanac', ";
			$sql.="(YEAR(CURRENT_DATE)-YEAR(persona_fecha_nacimiento))-(RIGHT(CURRENT_DATE,5)<RIGHT(persona_fecha_nacimiento,5))  'edad', persona_domicilio 'domicilio', localidad, departamento ";
			$sql.="FROM $salud._personas p ";			
			$sql.="JOIN $salud._localidades ON id_localidad = localidad_id ";
			$sql.="WHERE p.persona_id='$id_persona'";			
		}
		
		toXML($xml, $sql, "paciente");
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		
		break;
	}
	case 'dar_ingreso': {				
		$error="";
		$_ok="";
		//// INSERT O UPDATE EN LA TABLA PERSONAS
		$insert_personas = "";
		$id_persona = "";
		$xml_personas = loadXML($_REQUEST["persona"]);
		$count_childs = 0;
		foreach($xml_personas->children() as $child)
		{
			$count_childs++;
		}
		$i = 0;
		foreach($xml_personas->children() as $child)
		{
			$i++;
			if ($child->getName()!='persona_id') {								
				if ($i < $count_childs)
					if ($child->getName() == 'persona_fecha_nacimiento') {
						$fechanac = $child;
						if ($fechanac != '') {
							$fechanac = transformarFecha($child);												
							if ($fechanac == '') {
								$error .= 'La fecha de nacimiento ingresada no es válida';
							}								
						}
						$insert_personas.= $child->getName() . "='" . $fechanac. "', ";
					} else						
						$insert_personas.= $child->getName() . "='" . $child . "', ";
				else
					$insert_personas.= $child->getName() . "='" . $child . "'";
			} else {
				if ($child){
					$id_persona = $child; 
				}
			}
		}		
		if (!empty($error)) {			
			genero_xml_ok_errores($_ok,$error,'');
			break;
		}		
		if (!$id_persona) {
			// La persona no existe, darla de alta		
			$insert_personas = "INSERT INTO $salud._personas SET " . $insert_personas;			
			mysql_query($insert_personas);
			if (mysql_error()) {
				$error.=mysql_error();
			} else {
				$id_persona=mysql_insert_id();
				// Registrar el ingreso al establecimiento
				$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
						"fecha_consulta_ingreso = NOW(), " .
						"id_persona = '$id_persona', " .
						"id_nivel='2', " .
						"organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."'";
				mysql_query($insert_ingreso);
				$id_ingreso=mysql_insert_id();
				if (mysql_error()) {
					$error.=mysql_error();
				} else {
					// Registrar el ingreso al servicio
					$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
						"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = NOW(), circunstancia_ingreso='P', " .
						"id_area_servicio_ingreso='".$_SESSION['usuario_servicio_id']."'";				
					mysql_query($insert_ingreso_movimiento);
					if (mysql_error()) {
						$error.=mysql_error();
					}
				}
			}			
		} else {
			switch ($_REQUEST['accion_a_realizar']) {
				case 'dar_nuevo_ingreso': {
					// Registrar el ingreso al establecimiento
					$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
							"fecha_consulta_ingreso = NOW(), " .
							"id_persona = '$id_persona', " .
							"id_nivel='2', " .
							"organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."'";
					mysql_query($insert_ingreso);
					$id_ingreso=mysql_insert_id();
					if (mysql_error()) {
						$error.=mysql_error();
					} else {
						// Registrar el ingreso al servicio
						$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
							"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = NOW(), circunstancia_ingreso='P', " .
							"id_area_servicio_ingreso='".$_SESSION['usuario_servicio_id']."'";				
						mysql_query($insert_ingreso_movimiento);
						if (mysql_error()) {
							$error.=mysql_error();
						}
					}
					break;
				}
				case 'dar_nuevo_ingreso_movimiento': {
					// Registrar el ingreso al servicio
					$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
						"SET id_ingreso = '".$_REQUEST['id_ingreso']."', fecha_movimiento_ingreso = NOW(), circunstancia_ingreso='P', " .
						"id_area_servicio_ingreso='".$_SESSION['usuario_servicio_id']."'";				
					mysql_query($insert_ingreso_movimiento);
					if (mysql_error()) {
						$error.=mysql_error();
					}
					break;
				}
				case 'cerrar_ingreso_anterior': {
					$sql="UPDATE ingresos ";
					$sql.="SET id_tipo_egreso='5', ";
					$sql.="id_establecimiento_hacia='".$_SESSION['usuario_organismo_area_id']."' ";
					$sql.="WHERE id_ingreso='".$_REQUEST['id_ingreso']."' ";
					mysql_query($sql);
					if (mysql_error()) {
						$error.=mysql_error();
					} else {
						// Registrar el ingreso al establecimiento
						$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
								"fecha_consulta_ingreso = NOW(), " .
								"id_persona = '$id_persona', " .
								"id_nivel='2', " .
								"organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."'";
						mysql_query($insert_ingreso);
						$id_ingreso=mysql_insert_id();
						if (mysql_error()) {
							$error.=mysql_error();
						} else {
							// Registrar el ingreso al servicio
							$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
								"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = NOW(), circunstancia_ingreso='P', " .
								"id_area_servicio_ingreso='".$_SESSION['usuario_servicio_id']."'";				
							mysql_query($insert_ingreso_movimiento);
							if (mysql_error()) {
								$error.=mysql_error();
							}
						}
					}
					break;
				}
			}	
		}		
		genero_xml_ok_errores($_ok,$error,'');		
		break;
	}
	
	case "traer_localidades": {
		$xml=new SimpleXMLElement('<rows/>');
		$sql= "SELECT localidad_id, localidad ";
		$sql.= "FROM $salud._localidades ";
		$sql.= "WHERE localidad LIKE '%$localidad%' ";
		$sql.= "ORDER BY localidad ";
		
		$SELECT = mysql_query($sql);
		toXML($xml, $sql, "localidad");
		header('Content-Type: text/xml');
		echo $xml->asXML();

		break;
	}    
}
?>