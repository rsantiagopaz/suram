<?php
//extrae todo el arreglo Request y lo pone como variables
foreach ($_REQUEST as $key => $value)
{
 	if(get_magic_quotes_gpc()) {
    	${$key} = mysql_real_escape_string(stripslashes($value));
    } else {
        ${$key} = mysql_real_escape_string($value);
    }
}

function loadXML($data) {
  $xml = @simplexml_load_string($data);
  if (!is_object($xml))
    throw new Exception('Error en la lectura del XML',1001);
  return $xml;
}

function toXMLResult(&$xml, $error, $paramet, $tag = "row") {
	$nodo = null;
	if ($error != '') {
	 	$error="Error devuelto por la Base de Datos: ".mysql_error()."\n";
	 	$nodo=$xml->addChild("error", $error);
	} else {
		WHILE ($row = mysql_fetch_array($paramet)) {
			$nodo=$xml->addChild($tag);	
			foreach($row as $key => $value) {
				if (!is_numeric($key)) $nodo->addAttribute($key, $value);
			}
		}
	}	
	return $nodo;
}

function toXML(&$xml, $sql , $tag = "row") {	
	$paramet = @mysql_query($sql);
	$nodo = null;	
	if (mysql_insert_id()){ 
		$nodo=$xml->addChild("insert_id", mysql_insert_id());
	}
	if (mysql_errno()>0) {
	 	$error="Error devuelto por la Base de Datos: ".mysql_errno()." ".mysql_error()."\n";
	 	$nodo=$xml->addChild("error", $error);
	}
	else{
		if (is_resource($paramet)) {
			WHILE ($row = mysql_fetch_array($paramet)) {
				$nodo=$xml->addChild($tag);	
				foreach($row as $key => $value) {
					if (!is_numeric($key)) $nodo->addAttribute($key, $value);
				}
			}
			$nodo=null;
		} else if (is_array($paramet)) {
			$nodo=$xml->addChild($tag);
			foreach($paramet as $key => $value) {
				if (!is_numeric($key)) $nodo->addAttribute($key, $value);
			}
		} else if (is_a($paramet, "SimpleXMLElement")) {
			$nodo=$xml->addChild($paramet->getName(), $paramet);
			foreach($paramet->attributes() as $key => $value) {
	    		$nodo->addAttribute($key, $value);
			}
			foreach ($paramet->children() as $hijo) {
				toXML($nodo, $hijo);
			}
		} else if (is_string($paramet)) {
			$nodo=new SimpleXMLElement($paramet);
			$nodo=$xml->addChild($nodo->getName(), $nodo[0]);
		}
	}
	return $nodo;
}

function DMYYYY($fecha) {
	$f=explode("-", $fecha);
	return (int) $f[2] . "/" . (int) $f[1] . "/" . (int) $f[0];
}
function YYYYDM($fecha) {
	$fecha = explode('/',$fecha);
	$fecha = $fecha[2].'-'.$fecha[1].'-'.$fecha[0];
	
	return $fecha;
}
?>