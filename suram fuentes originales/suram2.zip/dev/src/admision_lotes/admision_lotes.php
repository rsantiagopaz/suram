<?php
include("../control_acceso_flex.php");
include("../rutinas.php");
include("../modelos/persona.php");
include("../util.php");

function dar_nuevo_ingreso($id_ingreso, $id_persona, $id_servicio, $fecha_ingreso, $usuario_organismo_area_id) {
	global $suram;
	$error = '';
	// Registrar el ingreso al establecimiento
	$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
			"fecha_consulta_ingreso = '".YYYYDM($fecha_ingreso)."', " .
			"id_persona = '$id_persona', " .
			"id_nivel='2', " .
			"organismo_area_id = '$usuario_organismo_area_id'";
	mysql_query($insert_ingreso);
	$id_ingreso=mysql_insert_id();
	if (mysql_error()) {
		$error .= mysql_error();
	} else {
		// Registrar el ingreso al servicio
		$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
			"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = '".YYYYDM($fecha_ingreso)."', circunstancia_ingreso='P', " .
			"id_area_servicio_ingreso='$id_servicio'";				
		mysql_query($insert_ingreso_movimiento);
		if (mysql_error()) {
			$error .= mysql_error();
		}
	}
	return $error;	
}

function dar_nuevo_ingreso_movimiento($id_ingreso, $id_servicio, $fecha_ingreso) {
	$error = '';
	// Registrar el ingreso al servicio
	$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
		"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = ".YYYYDM($fecha_ingreso).", circunstancia_ingreso='P', " .
		"id_area_servicio_ingreso='$id_servicio'";				
	mysql_query($insert_ingreso_movimiento);
	if (mysql_error()) {
		$error .= mysql_error();
	}
	return $error;	
}

function cerrar_ingreso_anterior($id_ingreso, $id_persona, $id_servicio, $fecha_ingreso, $usuario_organismo_area_id) {
	global $suram;
	$error = '';
	
	$sql="UPDATE ingresos ";
	$sql.="SET id_tipo_egreso='5', ";
	$sql.="id_establecimiento_hacia='$usuario_organismo_area_id' ";
	$sql.="WHERE id_ingreso='$id_ingreso' ";
	mysql_query($sql);
	if (mysql_error()) {
		$error.=mysql_error();
	} else {
		// Registrar el ingreso al establecimiento
		$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
				"fecha_consulta_ingreso = '".YYYYDM($fecha_ingreso)."', " .
				"id_persona = '$id_persona', " .
				"id_nivel='2', " .
				"organismo_area_id = '$usuario_organismo_area_id'";
		mysql_query($insert_ingreso);
		$id_ingreso=mysql_insert_id();
		if (mysql_error()) {
			$error .= mysql_error();
		} else {
			// Registrar el ingreso al servicio
			$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
				"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = '".YYYYDM($fecha_ingreso)."', circunstancia_ingreso='P', " .
				"id_area_servicio_ingreso='$id_servicio'";				
			mysql_query($insert_ingreso_movimiento);
			if (mysql_error()) {
				$error .= mysql_error();
			}
		}
	}
	return $error;
}

switch ($_REQUEST['rutina'])
{
	case 'lista_financiadores': {
		$xml=new SimpleXMLElement('<rows/>');
		
		$query = "SELECT id_persona FROM $suram.ingresos WHERE id_ingreso = '$id_ingreso'";
		
		$result = mysql_query($query);
				
		if ($nro_doc){
		$sql="SELECT id_financiador, nombre, codigo_anssal, descripcion ";
			$sql.="FROM $suram.padrones ";			
			$sql.="JOIN $suram.financiadores USING(id_financiador) ";
			$sql.="JOIN $suram.tipos_financiadores USING(id_tipo_financiador) ";
			$sql.="WHERE nrodoc='$nro_doc' ";
			$sql.="ORDER BY nombre";
		
		toXML($xml, $sql, "cobertura");
		}
		header('Content-Type: text/xml');
		echo $xml->asXML();
	
		break;
	}
	case 'datos_paciente': {
		
		$xml=new SimpleXMLElement('<rows/>');
		
		$query = "SELECT id_persona FROM $suram.ingresos WHERE id_ingreso = '$id_ingreso'";
		
		$result = mysql_query($query);
		
		if ($row = mysql_fetch_array($result)){						
			$id_persona = $row['id_persona'];
			
			$sql="SELECT persona_id 'id_persona',persona_nombre 'apeynom', persona_tipodoc 'tipo_doc', persona_dni 'nrodoc', IF( persona_sexo = 'M', 'MASCULINO', 'FEMENINO' ) as 'sexo', ";
			$sql.="DATE_FORMAT(persona_fecha_nacimiento,'%d/%m/%Y') as 'fechanac', ";
			$sql.="(YEAR(CURRENT_DATE)-YEAR(persona_fecha_nacimiento))-(RIGHT(CURRENT_DATE,5)<RIGHT(persona_fecha_nacimiento,5))  'edad', persona_domicilio 'domicilio', localidad, departamento ";
			$sql.="FROM $salud._personas p ";			
			$sql.="JOIN $salud._localidades ON id_localidad = localidad_id ";
			$sql.="WHERE p.persona_id='$id_persona'";			
		}
		
		toXML($xml, $sql, "paciente");
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		
		break;
	}
	case 'dar_ingreso': {				
		$error="";
		$_ok="";
		// INSERT O UPDATE EN LA TABLA PERSONAS		
		$id_persona = "";
		$xml_personas = loadXML($_REQUEST["persona"]);
		$persona = new persona();		
		
		$id_persona = $xml_personas->persona_id;		
		if ($id_persona == '') {			
			$resultado = $persona->salvar($xml_personas);			
			if ($resultado['error'] != '') {
				$error.=$resultado['error'];
			} else {
				$id_persona=$resultado['id'];
				// Registrar el número de historia clínica
				if ($xml_personas->persona_nro_historia_clinica != '') {
					$persona->registrar_nhc($id_persona, $_SESSION['usuario_organismo_area_id'], $xml_personas);					
				}
				// Registrar el ingreso al establecimiento
				$insert_ingreso = "INSERT INTO $suram.ingresos SET " .
						"fecha_consulta_ingreso = '".YYYYDM($fecha_ingreso)."', " .
						"id_persona = '$id_persona', " .
						"id_nivel='2', " .
						"organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."'";
				mysql_query($insert_ingreso);
				$id_ingreso=mysql_insert_id();
				if (mysql_error()) {
					$error.=mysql_error();
				} else {
					// Registrar el ingreso al servicio
					$insert_ingreso_movimiento = "INSERT INTO $suram.ingresos_movimientos " .
						"SET id_ingreso = '$id_ingreso', fecha_movimiento_ingreso = '".YYYYDM($fecha_ingreso)."', circunstancia_ingreso='P', " .
						"id_area_servicio_ingreso='$id_servicio'";				
					mysql_query($insert_ingreso_movimiento);
					if (mysql_error()) {
						$error.=mysql_error();
					}
				}
			}			
		} else {
			if ($xml_personas->persona_nro_historia_clinica != '') {
				// Verificar si la persona no tiene ya número de historia clínica para el hospital
				$tiene_nhc = $persona->verificar_tiene_nhc($id_persona, $_SESSION['usuario_organismo_area_id']);
				
				// Verificar si el número de historia clínica no existe para alguien más en el hospital
				$existe_nhc = $persona->verificar_existe_nhc($id_persona, $_SESSION['usuario_organismo_area_id'], $xml_personas->persona_nro_historia_clinica);				
				
				if ($tiene_nhc == 0 && $existe_nhc == 0) {
					$persona->registrar_nhc($id_persona, $_SESSION['usuario_organismo_area_id'], $xml_personas);
					mysql_query($sql);	
				}
			}
			switch ($_REQUEST['accion_a_realizar']) {
				case 'dar_nuevo_ingreso': {
					$error .= dar_nuevo_ingreso($_REQUEST['id_ingreso'], $id_persona, $id_servicio, $fecha_ingreso, $_SESSION['usuario_organismo_area_id']);
					break;					
				}
				case 'dar_nuevo_ingreso_movimiento': {
					$error .= dar_nuevo_ingreso_movimiento($_REQUEST['id_ingreso'], $id_servicio, $fecha_ingreso);					
					break;
				}
				case 'cerrar_ingreso_anterior': {
					$error .= cerrar_ingreso_anterior($_REQUEST['id_ingreso'], $id_persona, $id_servicio, $fecha_ingreso, $_SESSION['usuario_organismo_area_id']);					
					break;
				}
			}	
		}		
		genero_xml_ok_errores($_ok,$error,'');		
		break;
	}
	
	case "traer_localidades": {
		$xml=new SimpleXMLElement('<rows/>');
		$sql= "SELECT localidad_id, localidad ";
		$sql.= "FROM $salud._localidades ";
		$sql.= "WHERE localidad LIKE '%$localidad%' ";
		$sql.= "ORDER BY localidad ";
		
		$SELECT = mysql_query($sql);
		toXML($xml, $sql, "localidad");
		header('Content-Type: text/xml');
		echo $xml->asXML();

		break;
	}	
}
?>