<?php
//include("control_acceso_flex.php");
include("config.php");
include("rutinas.php");

switch ($_REQUEST['rutina'])
{
	case 'traer_datos':
 	{
 		$sql = "SELECT provincias_id 'provincia_id', provincias 'denom' ";
   		$sql.="FROM _provincias";   		
		$result = mysql_query($sql);
		
		$xml=new SimpleXMLElement('<rows/>');
				
		while ($row = mysql_fetch_array($result)) {
			$nodo2=$xml->addChild("provincia");			
			foreach($row as $key => $value) {						 
				if (!is_numeric($key)) $nodo2->addAttribute($key, $value);
			}
			$sql2 = "SELECT provincia_id, departamento_id, departamento 'denom' ";
	   		$sql2.="FROM _departamentos WHERE provincia_id='".$row['provincia_id']."'";   		   		
			$result2 = mysql_query($sql2);
			
			while ($row2 = mysql_fetch_array($result2)) {
				$nodo3=$nodo2->addChild("departamento");										 
				foreach($row2 as $key => $value) {										 
					if (!is_numeric($key)) $nodo3->addAttribute($key, $value);
				}
				
				$sql3 = "SELECT departamento_id, localidad_id, localidad 'denom' FROM _localidades JOIN _departamentos USING(departamento_id) ";			
				$sql3.= "WHERE departamento_id='".$row2['departamento_id']."'";						
				$result3 = mysql_query($sql3);			
				while ($row3 = mysql_fetch_array($result3)) {
					$nodo4=$nodo3->addChild("localidad");										 
					foreach($row3 as $key => $value) {										 
						if (!is_numeric($key)) $nodo4->addAttribute($key, $value);
					}
				}
			}					
		}		   			  	
		
		header('Content-Type: text/xml');     	     	
     	echo $xml->asXML();
    	break;
   }
}
?>
