<?php

class persona {
	public function __construct($salud = 'salud1', $suram = 'suram') {
		$this->salud = $salud;
		$this->suram = $suram;
	}
	
	public function buscar($id_persona) {
		$respuesta['error'] = '';
		$salud = $this->salud;		
		
		$sql="SELECT p.persona_id 'id_persona',persona_nombre 'apeynom', persona_tipodoc 'tipo_doc', persona_dni 'nrodoc', IF( persona_sexo = 'M', 'MASCULINO', 'FEMENINO' ) as 'sexo', ";
		$sql.="DATE_FORMAT(persona_fecha_nacimiento,'%d/%m/%Y') as 'fechanac', ";
		$sql.="(YEAR(CURRENT_DATE)-YEAR(persona_fecha_nacimiento))-(RIGHT(CURRENT_DATE,5)<RIGHT(persona_fecha_nacimiento,5))  'edad', persona_domicilio 'domicilio', localidad, departamento, provincias, ";
		$sql.="nro_historia_clinica ";
		$sql.="FROM $salud._personas p ";			
		$sql.="LEFT JOIN $salud._localidades l ON p.localidad_id = l.localidad_id ";
		$sql.="LEFT JOIN $salud._departamentos d USING(departamento_id) ";
		$sql.="LEFT JOIN $salud._provincias pr ON d.provincia_id = pr.provincias_id ";
		$sql.="LEFT JOIN personas_hospitales ph ON (p.persona_id = ph.persona_id AND ph.organismo_area_id='".$_SESSION['usuario_organismo_area_id']."') ";
		$sql.="WHERE p.persona_id='$id_persona'";
		
		$result = mysql_query($sql);
		if (mysql_error()) {			
			$respuesta['error'] = mysql_error();			
		} else {
			$respuesta['resultado'] = $result;
		}
		return $respuesta;
	}
	
	public function salvar($xml_personas) {
		$respuesta['error'] = '';
		$respuesta['id'] = '';
		$salud = $this->salud;
		
		$insert_update = "SET persona_nombre='".$xml_personas->persona_nombre."', ";
		$insert_update.= "persona_tipodoc='".$xml_personas->persona_tipodoc."', ";
		$insert_update.= "persona_dni='".$xml_personas->persona_dni."', ";
		$insert_update.= "persona_fecha_nacimiento='".transformarFecha($xml_personas->persona_fecha_nacimiento)."', ";
		$insert_update.= "persona_sexo='".$xml_personas->persona_sexo."', ";
		$insert_update.= "persona_domicilio='".$xml_personas->persona_domicilio."', ";		
		$insert_update.= "localidad_id='".$xml_personas->localidad_id."' ";
		$id_persona = $xml_personas->persona_id;	
		if ($id_persona == '') {
			$sql = "INSERT INTO $salud._personas " . $insert_update;			
		}			
		else {
			$sql = "UPDATE $salud._personas " . $insert_update . "WHERE persona_id = '".$xml_personas->persona_id."'";			
		}
		mysql_query($sql);
		if (mysql_error()) {			
			$respuesta['error'] = mysql_error();			
		} else {
			if ($id_persona == '') $id_persona = mysql_insert_id();
			$respuesta['id'] = $id_persona;
		}
		return $respuesta;
	}
	
	public function registrar_nhc($id_persona, $usuario_organismo_area_id, $xml_personas) {
		$respuesta['error'] = '';		
		$sql ="INSERT INTO personas_hospitales SET ";
		$sql.="persona_id='$id_persona', ";
		$sql.="organismo_area_id = '$usuario_organismo_area_id', ";
		$sql.="nro_historia_clinica='".$xml_personas->persona_nro_historia_clinica."'";
		mysql_query($sql);
		if (mysql_error()) {			
			$respuesta['error'] = mysql_error();			
		}
	}
	
	public function actualizar_nhc($id_persona, $usuario_organismo_area_id, $xml_personas) {
		$respuesta['error'] = '';
		$sql ="UPDATE personas_hospitales SET ";		
		$sql.="nro_historia_clinica='".$xml_personas->persona_nro_historia_clinica."' ";
		$sql.="WHERE persona_id = '$id_persona' ";
		$sql.="AND organismo_area_id = '$usuario_organismo_area_id'";
		mysql_query($sql);
		if (mysql_error()) {			
			$respuesta['error'] = mysql_error();			
		}
	}
	
	public function verificar_tiene_nhc($id_persona, $usuario_organismo_area_id) {
		$sql ="SELECT COUNT(*) 'chc' FROM personas_hospitales ";
		$sql.="WHERE persona_id = '$id_persona' ";
		$sql.="AND organismo_area_id = '$usuario_organismo_area_id'";		
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		if ($row['chc'] > 0)
			return 1;
		else
			return 0;
	}
	
	public function verificar_existe_nhc($id_persona, $usuario_organismo_area_id, $nro_historia_clinica) {
		$sql ="SELECT COUNT(*) 'chc' FROM personas_hospitales ";
		$sql.="WHERE persona_id != '$id_persona' ";
		$sql.="AND organismo_area_id = '$usuario_organismo_area_id' ";
		$sql.="AND nro_historia_clinica='$nro_historia_clinica'";		
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		if ($row['chc'] > 0)
			return 1;
		else
			return 0;
	}
}
?>
