<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case 'insert': 
	{
		$error = "";
		
		$_REQUEST["xmlPractica"] = str_replace('\"','"',$_REQUEST["xmlPractica"]);
		$xml_practica = loadXML($_REQUEST["xmlPractica"]);	
		
		$fecha_solicitud = YYYYDM($xml_practica["fecha_solicitud"]);
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT fecha_movimiento_ingreso ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso_movimiento = '".$xml_practica["id_ingreso_movimiento_solicitud"]."'";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$fecha_practica = new DateTime($fecha_solicitud);
		$fecha_movimiento = new DateTime($row['fecha_movimiento_ingreso']);
		
		if ($fecha_practica < $fecha_movimiento) {
			$error .= "La fecha de solicitud no puede ser anterior a la fecha de ingreso al servicio\n";
		}
		
		if ($error == "") {
			$sql="INSERT solicitudes ";
			$sql.="SET id_ingreso_movimiento_solicitud='".$xml_practica["id_ingreso_movimiento_solicitud"]."', ";
			$sql.="id_practica='".$xml_practica["id_practica"]."', ";
			$sql.="resultados='".$xml_practica["resultados"]."', ";
			$sql.="fecha_solicitud='$fecha_solicitud' ";
			toXML($xml, $sql, "add");
					
			header('Content-Type: text/xml');
			echo $xml->asXML();	
		} else {
			$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
			$xml .= "<xml>";
			$xml .= "<error>$error</error>";			
			$xml.= "</xml>";
			header('Content-Type: text/xml');
			print $xml;
		}		
		break;
	}
	case 'update': 
	{
		$error = "";
		
		$_REQUEST["xmlPractica"] = str_replace('\"','"',$_REQUEST["xmlPractica"]);
		$xml_practica = loadXML($_REQUEST["xmlPractica"]);	
		
		$fecha_solicitud = YYYYDM($xml_practica["fecha_solicitud"]);
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT fecha_movimiento_ingreso ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso_movimiento = '".$xml_practica["id_ingreso_movimiento_solicitud"]."'";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$fecha_practica = new DateTime($fecha_solicitud);
		$fecha_movimiento = new DateTime($row['fecha_movimiento_ingreso']);
		
		if ($fecha_practica < $fecha_movimiento) {
			$error .= "La fecha de solicitud no puede ser anterior a la fecha de ingreso al servicio\n";
		}
		
		if ($error == "") {
			$sql="UPDATE solicitudes ";
			$sql.="SET id_practica='".$xml_practica["id_practica"]."', ";
			$sql.="resultados='".$xml_practica["resultados"]."', ";
			$sql.="fecha_solicitud='$fecha_solicitud' ";
			$sql.="WHERE id_solicitudes='".$xml_practica["id_solicitudes"]."' ";
			toXML($xml, $sql, "upd");
					
			header('Content-Type: text/xml');
			echo $xml->asXML();	
		} else {
			$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
			$xml .= "<xml>";
			$xml .= "<error>$error</error>";			
			$xml.= "</xml>";
			header('Content-Type: text/xml');
			print $xml;
		}
		break;
	}
	case 'delete': 
	{
		$_REQUEST["xmlPractica"] = str_replace('\"','"',$_REQUEST["xmlPractica"]);
		$xml_practica = loadXML($_REQUEST["xmlPractica"]);	
		
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="DELETE FROM solicitudes ";
		$sql.="WHERE id_solicitudes='".$xml_practica["id_solicitudes"]."' ";
		toXML($xml, $sql, "del");
				
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
}

?>