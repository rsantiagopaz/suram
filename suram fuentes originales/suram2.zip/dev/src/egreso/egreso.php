<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case 'traer_combos': {
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT * ";
		$sql.="FROM tipos_egresos ";
		$sql.="WHERE id_tipo_egreso <> '5' ";
		$sql.="ORDER BY descripcion";
		toXML($xml, $sql, "tegreso");						

		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
	case "traer_medicos":{
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT persona_nombre, _personal.id_personal ";
        $sql.="FROM _personal ";
        $sql.="INNER JOIN _organismos_areas_servicios ON _personal.id_areas_servicios = _organismos_areas_servicios.id_organismo_area_servicio AND ";
        $sql.="_organismos_areas_servicios.id_organismo_area_servicio IN ";
        $sql.="(";
            $sql.="SELECT id_organismo_area_servicio ";
            $sql.="FROM _organismos_areas_servicios ";
        	$sql.="WHERE id_organismo_area = '".$_SESSION['usuario_organismo_area_id']."' ";
        $sql.=") ";
        $sql.="INNER JOIN _organismos_areas ON _organismos_areas_servicios.id_organismo_area = _organismos_areas.organismo_area_id ";
        $sql.="INNER JOIN _servicios ON _organismos_areas_servicios.id_servicio = _servicios.id_servicio ";
        $sql.="INNER JOIN 024_profesiones ON _personal.id_profesion = 024_profesiones.id_profesion AND 024_profesiones.id_profesion IN ('1') ";        
        $sql.="INNER JOIN _personas ON _personal.dni = _personas.persona_dni ";
        
        /*$sql.="INNER JOIN _usuarios ON _personas.persona_id = _usuarios.id_persona ";
        $sql.="INNER JOIN oas_usuarios ON _personal.id_areas_servicios = oas_usuarios.id_organismo_area_servicio ";
        $sql.="AND _usuarios.SYSusuario = oas_usuarios.SYSusuario ";*/
        
        $sql.="WHERE persona_nombre LIKE '%$nombre%' ";
        $sql.="ORDER BY persona_nombre ";        
		
		toXML($xml, $sql, "medico");
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}	
	case "traer_establecimientos":{
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT organismo_area_id 'id_establecimiento', organismo_area 'descripcion'";
		$sql.="FROM $salud._organismos_areas ";
		$sql.="WHERE organismo_area_tipo_id='E' ";
		$sql.="AND organismo_area_estado='1' ";
		$sql.= "AND organismo_area LIKE '%$descripcion%' ";
		$sql.="ORDER BY organismo_area";
		toXML($xml, $sql, "establecimiento");
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
	case "guardar":{
		$fecha_egreso = YYYYDM($fecha_egreso);
			
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT DATE_FORMAT(fecha_movimiento_ingreso,'%Y-%m-%d') 'fecha_movimiento_ingreso' ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
		
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		
		$fecha_movimiento_ingreso = new DateTime($row['fecha_movimiento_ingreso']);
		$fecha_movimiento_egreso = new DateTime($fecha_egreso);
		
		if ($fecha_movimiento_egreso >= $fecha_movimiento_ingreso) {
			$sql="UPDATE ingresos_movimientos ";
			$sql.="SET fecha_movimiento_egreso='$fecha_egreso', ";
			$sql.="id_recursos_humanos_egreso='$id_medico', ";
			$sql.="observaciones_egreso='$observaciones' ";
			$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
			toXML($xml, $sql, "egreso");
			
			$sql="SELECT id_ingreso ";
			$sql.="FROM ingresos_movimientos ";
			$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
			$row = mysql_query($sql);
			$rs = mysql_fetch_array($row);
			$id_ingreso = $rs['id_ingreso'];
				
			//pregunto si se trata de un traslado
			if ($id_tipo_egreso=="2"){
				$sql="UPDATE ingresos ";
				$sql.="SET id_tipo_egreso='$id_tipo_egreso', ";
				$sql.="id_establecimiento_hacia='$id_establecimiento' ";
				$sql.="WHERE id_ingreso='$id_ingreso' ";
				toXML($xml, $sql, "egreso1");
			} else {
				$sql="UPDATE ingresos ";
				$sql.="SET id_tipo_egreso='$id_tipo_egreso' ";
				$sql.="WHERE id_ingreso='$id_ingreso' ";
				toXML($xml, $sql, "egreso1");
			}
			
			header('Content-Type: text/xml');
			echo $xml->asXML();	
		} else {
			$error = "La fecha de egreso no puede ser anterior a la fecha de ingreso al servicio\n";
			$xml = "<?xml version='1.0' encoding='UTF-8' ?>";
			$xml .= "<xml>";
			$xml .= "<error>$error</error>";			
			$xml.= "</xml>";
			header('Content-Type: text/xml');
			print $xml;
		}
				
		break;
	}			
}
?>