<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

if (!isset($filtro_pacientes))
	$filtro_pacientes = '';

switch ($_REQUEST['rutina'])
{
	case 'lista_pacientes': {

		$xml=new SimpleXMLElement('<rows/>');
		$sql="SELECT i.id_ingreso, im.id_ingreso_movimiento, p.persona_nombre 'apeynom', ";
		$sql.="CASE p.persona_tipodoc WHEN 'D' THEN 'DNI' WHEN 'C' THEN 'LC' WHEN 'E' THEN 'LE' WHEN 'F' THEN 'CI' END as 'tipo_doc',p.persona_dni 'nrodoc', DATE_FORMAT(fecha_movimiento_ingreso,'%d/%m/%Y') 'fecha_ingreso', ";
		$sql.="denominacion, IF (id_tipo_egreso IS NULL,'abierto','cerrado') 'estado' ";
		$sql.="FROM $suram.ingresos_movimientos im ";
		$sql.="INNER JOIN $suram.ingresos i USING(id_ingreso) ";
		$sql.="INNER JOIN $salud._personas p ON i.id_persona=p.persona_id ";		
		$sql.="INNER JOIN $salud._organismos_areas_servicios oas ON im.id_area_servicio_ingreso = oas.id_organismo_area_servicio ";
		$sql.="INNER JOIN $salud._servicios s ON im.id_area_servicio_ingreso = s.id_servicio ";
		//Queremos todos los pacientes del área, no sólo los del servicio del usuario
		$sql.="WHERE i.organismo_area_id = '".$_SESSION['usuario_organismo_area_id']."' ";        
		$sql.="AND i.id_nivel='2' ";
		$sql.="AND i.id_ingreso = '$idIngreso' ";
		$sql.="ORDER BY im.id_ingreso_movimiento";
		
		toXML($xml, $sql, "pacientes");
		header('Content-Type: text/xml');
		echo $xml->asXML();
	
		break;
	}
	
	case 'eliminar_movimiento': {
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="SELECT id_ingreso, IF (id_tipo_egreso IS NULL,'abierto','cerrado') 'estado' ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="JOIN ingresos USING(id_ingreso) ";
		$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento'";
		
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		$id_ingreso = $row['id_ingreso'];
		$estado = $row['estado'];
		
		if ($estado == "cerrado") {
			$sql="UPDATE ingresos ";
			$sql.="SET id_tipo_egreso=NULL, ";
			$sql.="id_establecimiento_hacia=NULL ";
			$sql.="WHERE id_ingreso='$id_ingreso'";
			toXML($xml, $sql, "del");						
		}
		
		// Eliminar items de diagnóstico
		$sql ="DELETE itd FROM items_diagnosticos itd ";
		$sql.="INNER JOIN ingresos_movimientos im USING(id_ingreso_movimiento) ";
		$sql.="WHERE id_ingreso='$id_ingreso' ";
		$sql.="AND im.id_ingreso_movimiento >= '$id_ingreso_movimiento'";
		toXML($xml, $sql, "del");
		
		// Eliminar prescricpiones
		$sql ="DELETE pr FROM prescripciones pr ";
		$sql.="INNER JOIN ingresos_movimientos im USING(id_ingreso_movimiento) ";
		$sql.="WHERE id_ingreso='$id_ingreso' ";
		$sql.="AND im.id_ingreso_movimiento >= '$id_ingreso_movimiento'";
		toXML($xml, $sql, "del");
		
		// Eliminar solicitudes
		$sql ="DELETE sol FROM solicitudes sol ";
		$sql.="INNER JOIN ingresos_movimientos im ON sol.id_ingreso_movimiento_solicitud = im.id_ingreso_movimiento ";
		$sql.="WHERE id_ingreso='$id_ingreso' ";
		$sql.="AND im.id_ingreso_movimiento >= '$id_ingreso_movimiento'";
		toXML($xml, $sql, "del");
		
		// Eliminar ingresos movimientos, desde el ingreso movimiento a eliminar
		// en adelante
		$sql ="DELETE FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso='$id_ingreso' ";
		$sql.="AND id_ingreso_movimiento >= '$id_ingreso_movimiento'";
		toXML($xml, $sql, "del");
		
		$sql="SELECT COUNT(id_ingreso_movimiento) 'cc' ";
		$sql.="FROM ingresos_movimientos ";
		$sql.="WHERE id_ingreso='$id_ingreso'";
		$result = mysql_query($sql);
		$row = mysql_fetch_array($result);
		
		// Si no hay más ingresos movimientos, entonces eliminar también el ingreso
		if ($row['cc'] == 0) {
			$sql ="DELETE FROM ingresos ";
			$sql.="WHERE id_ingreso ='$id_ingreso'";
			toXML($xml, $sql, "del");
		}
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
	}
}
?>