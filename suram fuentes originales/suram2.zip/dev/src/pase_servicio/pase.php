<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case 'traer_combos': {
		$xml=new SimpleXMLElement('<rows/>');
		$id_area = $_SESSION['usuario_organismo_area_id'];

		$sql="SELECT id_organismo_area_servicio 'id_area_servicio', denominacion ";
		$sql.="FROM $salud._organismos_areas_servicios oas ";
		$sql.="INNER JOIN $salud._servicios USING(id_servicio) ";
		$sql.="WHERE oas.id_organismo_area='$id_area' ";
		$sql.="ORDER BY denominacion";
		toXML($xml, $sql, "servicio");				
		
		$sql="SELECT persona_nombre, _personal.id_personal ";		
        $sql.="FROM _personal ";
        $sql.="INNER JOIN _organismos_areas_servicios ON _personal.id_areas_servicios = _organismos_areas_servicios.id_organismo_area_servicio AND ";
        $sql.="_organismos_areas_servicios.id_organismo_area_servicio IN ";
        $sql.="(";
            $sql.="SELECT id_organismo_area_servicio ";
            $sql.="FROM _organismos_areas_servicios ";
        	$sql.="WHERE id_organismo_area = '".$_SESSION['usuario_organismo_area_id']."' ";
        $sql.=") ";
        $sql.="INNER JOIN _organismos_areas ON _organismos_areas_servicios.id_organismo_area = _organismos_areas.organismo_area_id ";
        $sql.="INNER JOIN _servicios ON _organismos_areas_servicios.id_servicio = _servicios.id_servicio ";
        $sql.="INNER JOIN 024_profesiones ON _personal.id_profesion = 024_profesiones.id_profesion AND 024_profesiones.id_profesion IN ('1') ";        
        $sql.="INNER JOIN _personas ON _personal.dni = _personas.persona_dni ";
        $sql.="INNER JOIN _usuarios ON _personas.persona_id = _usuarios.id_persona ";
        $sql.="INNER JOIN oas_usuarios ON _personal.id_areas_servicios = oas_usuarios.id_organismo_area_servicio ";
        $sql.="AND _usuarios.SYSusuario = oas_usuarios.SYSusuario ";
        $sql.="ORDER BY persona_nombre ";                     
		toXML($xml, $sql, "medico");
		
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
	case "guardar":{
		$fecha_pase = YYYYDM($fecha_pase);
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="UPDATE ingresos_movimientos ";
		$sql.="SET fecha_movimiento_egreso='$fecha_pase', ";
		$sql.="id_area_servicio_egreso='$id_servicio', ";
		$sql.="id_recursos_humanos_egreso='$id_medico', ";
		$sql.="observaciones='$observaciones' ";
		$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
		toXML($xml, $sql, "pase");
				
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
}
?>