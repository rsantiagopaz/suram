<?php
include("../control_acceso_flex.php");
include("../rutinas.php");

switch ($_REQUEST['rutina'])
{
	case "guardar":{		
		$xml=new SimpleXMLElement('<rows/>');
		
		$sql="UPDATE ingresos_movimientos ";
		$sql.="SET observaciones='$observaciones' ";
		$sql.="WHERE id_ingreso_movimiento='$id_ingreso_movimiento' ";
		toXML($xml, $sql, "observaciones");
			
		header('Content-Type: text/xml');
		echo $xml->asXML();
		break;
	}
	
		
}
?>